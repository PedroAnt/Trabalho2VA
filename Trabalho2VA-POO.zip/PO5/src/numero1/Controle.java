package numero1;

public interface Controle {
	
	public void andar();
	
	public void virar();
	
	public void falar();
	
}
