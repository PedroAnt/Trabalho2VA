package numero1;

public class UsaRobo {
	
	public static void main(String[] args) {
		
		Robo rb1 = new Robo();
		
		rb1.andar();
		rb1.falar();
		rb1.virar();
		
		
		
	}	
	
}
