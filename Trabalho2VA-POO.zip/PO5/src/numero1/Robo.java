package numero1;

public class Robo implements Controle{
	
	public  void andar(){
		System.out.println("O robo est� andando!");
	}
	
	public void virar(){
		System.out.println("O robo est� virando!");
	}
	
	public  void falar(){
		System.out.println("O robo est� falando!");
	}
	
}
