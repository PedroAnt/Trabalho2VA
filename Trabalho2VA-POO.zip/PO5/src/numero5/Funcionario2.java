package numero5;

public class Funcionario2 extends Funcionario1{
	
	String Escola;
	
	Funcionario2(String Nome, int Codigo, String Escola) {
		super(Nome, Codigo);
		this.Escola=Escola;		
	}
	
	public String getEscola() {
		return Escola;
	}
	
	public void setEscola(String Escola) {
		this.Escola=Escola;
	}

	public void Registro() {
		System.out.println("Nome do Funcionario que concluiu o ensino basico: " +this.getNome());
		System.out.println("Codigo do Funcionario que concluiu o ensino basico: " +this.getCodigo());
		System.out.println("Nome da Escola do Funcionario que concluiu o ensino basico: " +this.getEscola()+"\n");
	}
	
}
