package numero5;

public class Principal {
	
	public static void main(String[] args) {
		
		Funcionario1 Funcionario01 = new Funcionario1("Pedro", 1);
		Funcionario2 Funcionario02 = new Funcionario2("Jo�o", 2, "CPMG");
		Funcionario3 Funcionario03 = new Funcionario3("Eduardo", 3 , "CPMG");
		Funcionario4 Funcionario04 = new Funcionario4("Andre", 4, "UNI");
		
		Funcionario01.Registro();
		Funcionario02.Registro();
		Funcionario03.Registro();
		Funcionario04.Registro();
	}
	
		

}
