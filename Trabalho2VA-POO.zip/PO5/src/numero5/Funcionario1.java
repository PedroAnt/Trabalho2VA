package numero5;

public class Funcionario1 {
	String Nome;
	int Codigo;
	
	Funcionario1(String Nome, int Codigo){
		this.Nome=Nome;
		this.Codigo=Codigo;
	}
	
	public String getNome() {
		return Nome;
	}
	
	public void setNome(String Nome) {
		this.Nome=Nome;
	}
	
	public int getCodigo() {
		return Codigo;
	}
	
	public void setCodigo(int Codigo) {
		this.Codigo=Codigo;
	}
	
	public void Registro() {
		System.out.println("Nome do funcionario que n�o estudou: " +this.getNome());
		System.out.println("Codigo do funcionario que n�o estudou: " +this.getCodigo()+"\n");
	}

}
