package numero8;

public class Cliente extends Geral {
	
	Cliente(String Nome, String Endereco, int Telefone){
		super(Nome,Endereco,Telefone);
	}
	
	
	public void Dados() {
		System.out.println("Nome do cliente: " +this.getNome());
		System.out.println("Endereco do cliente: " +this.getEndereco());
		System.out.println("Telefone do clente: " +this.getTelefone()+"\n");
		
	}
}
