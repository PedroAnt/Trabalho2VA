package numero8;

public class Fisica extends Geral {

	int CPF;
	
	Fisica(String Nome, String Endereco, int Telefone, int CPF) {
		super(Nome, Endereco, Telefone);
		this.CPF=CPF;
	}
	
	public int getCPF() {
		return CPF;
	}
	
	public void setCPF(int CPF) {
		this.CPF=CPF;
	}
	
	public void Dados() {
		System.out.println("Nome do cliente: " +this.getNome());
		System.out.println("Endereco do cliente: " +this.getEndereco());
		System.out.println("Telefone do clente: " +this.getTelefone());
		System.out.println("CPF do cliente: " +this.getCPF()+"\n");
	}
	
}
