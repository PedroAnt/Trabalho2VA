package numero4;

public class Funcionario {

	String nome;
	
	Funcionario(String nome){
		this.nome=nome;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome=nome;
	}
	
	public void exibeDados() {
		System.out.println("Dados do Funcionario: " + this.getNome()+"\n");
	}
}
