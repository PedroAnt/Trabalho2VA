package numero4;

public class Assistente extends Funcionario {

	int matricula;
	
	Assistente(String nome, int matricula) {
		super(nome);
		this.matricula=matricula;
	}
	
	public double getMatricula() {
		return matricula;
	}
	
	public void setMatricula(int matricula) {
		this.matricula=matricula;
	}
	
	public void exibeDados() {
		System.out.println("Dados do Assistente: " + this.getMatricula()+","+this.getNome()+"\n");
	}
	
}
