package numero4;

public class Administrativo extends Assistente {
	
	String turno;
	double adicionalSalarial;
	
	Administrativo(String nome, int matricula, String turno, double adicionalSalarial) {
		super(nome, matricula);
		this.turno=turno;
		this.adicionalSalarial=adicionalSalarial;
	}

	public String getTurno() {
		return turno;
	}
	
	public void setTurno(String turno) {
		this.turno=turno;
	}

	public double getAdicionalSalarial() {
		return adicionalSalarial;
	}
	
	public void setAdicionalSalarial(double adicionalSalarial) {
		this.adicionalSalarial=adicionalSalarial;
	}
	
	public void exibeDados() {
		System.out.println("Nome do AssistenteAdminstrativo: " +"\n"+this.getNome()+","+"\n"+this.getMatricula()+","+"\n"+this.getTurno()+","+"\n"+this.getAdicionalSalarial());
		}
	
}
