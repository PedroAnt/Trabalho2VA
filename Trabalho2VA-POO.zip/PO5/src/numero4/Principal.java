package numero4;

public class Principal {
	public static void main(String[] args) {
		Funcionario Funcionario1 = new Funcionario("Pedro");
		
		Assistente Funcionario2 = new Assistente("Jo�o",1);
		
		Administrativo Funcionario3 = new Administrativo("Lucas",2,"Noite",100);
		
		Tecnico Funcionario4 = new Tecnico("Matheus",3,200);
		
		Funcionario1.exibeDados();
		Funcionario2.exibeDados();
		Funcionario3.exibeDados();
		Funcionario4.exibeDados();
		
		
	}

}
