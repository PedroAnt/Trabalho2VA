package numero4;

public class Tecnico extends Assistente {

	double bonussalarial;
	
	Tecnico(String nome, int matricula,double bonussalarial) {
		super(nome, matricula);
		this.bonussalarial=bonussalarial;
	}
	
	public double getBonussalarial() {
		return bonussalarial;
	}
	
	public void setBonusslarial(double bonussalarial) {
		this.bonussalarial=bonussalarial;
	}
	
	public void exibeDados() {
		System.out.println("Nome do AssistenteTecnico: " +this.getNome() );
		System.out.println("Matricula do AssistenteTecnico: " +this.getMatricula());
		System.out.println("BonusSalarial do AssistenteTecnico: " +this.getBonussalarial()+"\n");
	}

}
