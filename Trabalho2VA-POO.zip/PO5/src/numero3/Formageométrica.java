package numero3;

public interface Formageom�trica {
	
	public double calculoPerimetro();
	public double calculoArea();

}
