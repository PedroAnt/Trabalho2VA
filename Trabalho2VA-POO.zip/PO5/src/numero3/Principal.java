package numero3;

public class Principal {
	
	public static void main(String[] args) {
		
		Circulo Formageometrica1 = new Circulo(10);
		Quadrado Formageometrica2 = new Quadrado(10, 0, 0, 0, 0);
		Retangulo Formageometrica3 = new Retangulo(5, 20, 10, 10, 10, 10);
		
		Formageometrica1.calculoArea();
		Formageometrica1.calculoPerimetro();
		Formageometrica2.calculoArea();
		Formageometrica2.calculoPerimetro();
		Formageometrica3.calculoArea();
		Formageometrica3.calculoPerimetro();
		
	}

}
