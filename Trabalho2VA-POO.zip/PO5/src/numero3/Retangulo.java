package numero3;

public class Retangulo extends Quadrilatero {
	
	protected float base;
	protected float altura;
	
	Retangulo(float base,float altura,double lado1,double lado2,double lado3,double lado4){
		super(lado1,lado2,lado3,lado4);
		this.base=base;
		this.altura=altura;
	}
	
	public float getBase() {
		return base;
	}
	
	public void setBase(float base) {
		this.base=base;
	}
	
	public float getAltura() {
		return altura;
	}

	public void setAltura(float altura) {
		this.altura=altura;
	}

	@Override
	public double calculoPerimetro() {
	
		return this.getBase()*2+this.getAltura()*2;
		
	}

	@Override
	public double calculoArea() {
		
		return this.getBase()*this.getAltura();
	}
	
}
