package numero3;

public class Quadrado extends Quadrilatero {
	protected double lado;
	
	Quadrado (double lado,double lado1,double lado2,double lado3,double lado4){
		super(lado1,lado2,lado3,lado4);
		this.lado=lado;		
	}
	
	public double getLado() {
		return lado;
	}
	
	public void setLado(double lado) {
		this.lado=lado;
	}

	@Override
	public double calculoPerimetro() {
		
		return this.getLado()*4;
		
	}

	@Override
	public double calculoArea() {
		
		return this.getLado()*this.getLado();
		
	}
	
}
