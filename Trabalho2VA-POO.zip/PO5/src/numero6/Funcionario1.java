package numero6;

public class Funcionario1 {
	String Nome;
	int Codigo;
	double rendaBasica;
	
	Funcionario1(String Nome, int Codigo, double rendaBasica){
		this.Nome=Nome;
		this.Codigo=Codigo;
		this.rendaBasica=rendaBasica;
	}
	
	public String getNome() {
		return Nome;
	}
	
	public void setNome(String Nome) {
		this.Nome=Nome;
	}
	
	public int getCodigo() {
		return Codigo;
	}
	
	public void setCodigo(int Codigo) {
		this.Codigo=Codigo;
	}
	
	public double getRendaBasica() {
		return rendaBasica;
	}
	
	public void setRendaBasica(double rendaBasica) {
		this.rendaBasica=rendaBasica;
	}
	
	public void Registro() {
		System.out.println("Nome do funcionario que n�o estudou: " +this.getNome());
		System.out.println("Codigo do funcionario que n�o estudou: " +this.getCodigo());
		System.out.println("Renda basica que n�o estudou: " +this.getRendaBasica()+"\n");
	}

}
