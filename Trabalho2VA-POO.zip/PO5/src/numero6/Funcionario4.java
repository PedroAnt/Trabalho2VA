package numero6;

public class Funcionario4 extends Funcionario1{

	String Universidade;
	
	Funcionario4(String Nome, int Codigo, String Universidade, double rendaBasica) {
		super(Nome, Codigo, rendaBasica);
		this.Universidade=Universidade;
	}

	public String getUniversidade() {
		return Universidade;
	}

	public void setUniversidade(String Universidade) {
		this.Universidade = Universidade;
	}
	
	public void Registro() {
		System.out.println("Nome do funcionario que concluiu a gradua��o: " +this.getNome());
		System.out.println("Codigo do funcionario que concluiu a gradua��o: " +this.getCodigo());
		System.out.println("Universidade do funcionario que concluiu a gradu��o: " +this.getUniversidade());
		System.out.println("Renda total do funcionario que concluiu a gradu��o: " +this.getRendaBasica()*2+"\n");
	}
}
