package numero6;

public class Funcionario3 extends Funcionario2{

	Funcionario3(String Nome, int Codigo, String Escola, double rendaBasica) {
		super(Nome, Codigo, Escola, rendaBasica);
	}
	
	public void Registro() {
		System.out.println("Nome do funcionario que concluiu o ensino m�dio: " +this.getNome());
		System.out.println("Codigo do funcionario que concluiu o ensino m�dio: " +this.getCodigo());
		System.out.println("Escola do funcionario que concluiu o ensino m�dio: " +this.getEscola());
		System.out.println("Renda basica do funcionario que concluiu o ensino m�dio: " +this.getRendaBasica()*1.50+"\n");
	}
	

}
