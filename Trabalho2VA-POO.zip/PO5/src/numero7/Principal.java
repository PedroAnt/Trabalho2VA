package numero7;

public class Principal {
	
	public static void main(String[] args) {
		Cliente cliente1 = new Cliente("Pedro","Rua",123456);
		Fisica cliente2 = new Fisica("Pedro","Rua",123456,741852963);
		Juridica cliente3 = new Juridica("Pedro","Rua",123456,258147369,"Empresa");
		
		cliente1.Dados();
		cliente2.Dados();
		cliente3.Dados();
	}
	

}
