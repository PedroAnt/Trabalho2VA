package numero7;

public class Juridica extends Cliente {

	int CNPJ;
	String NomeFantasia;
	
	Juridica(String Nome, String Endereco, int Telefone, int CNPJ, String NomeFantasia) {
		super(Nome, Endereco, Telefone);
		this.CNPJ=CNPJ;
		this.NomeFantasia=NomeFantasia;
	}

	public int getCNPJ() {
		return CNPJ;
	}

	public void setCNPJ(int cNPJ) {
		CNPJ = cNPJ;
	}

	public String getNomeFantasia() {
		return NomeFantasia;
	}

	public void setNomefantasia(String NomeFantasia) {
		this.NomeFantasia = NomeFantasia;
	}
	
	public void Dados() {
		System.out.println("Nome do cliente: " +this.getNome());
		System.out.println("Endereco do cliente: " +this.getEndereco());
		System.out.println("Telefone do clente: " +this.getTelefone());
		System.out.println("CNPJ da empresa: " +this.getCNPJ());
		System.out.println("Nome fantasia da empresa: " +this.getNomeFantasia()+"\n");
	}
	

}
