package numero7;

public class Cliente {
	
	String Nome;
	String Endereco;
	int Telefone;
	
	Cliente(String Nome, String Endereco, int Telefone){
		this.Nome=Nome;
		this.Endereco=Endereco;
		this.Telefone=Telefone;
	}
	
	public String getNome() {
		return Nome;
	}
	
	public void setNome(String Nome) {
		this.Nome=Nome;
	}

	public String getEndereco() {
		return Endereco;
	}
	
	public void setEndereco(String Endereco) {
		this.Endereco=Endereco;
	}
	
	public int getTelefone() {
		return Telefone;
	}
	
	public void setEndereco(int Telefone) {
		this.Telefone=Telefone;
	}
	
	public void Dados() {
		System.out.println("Nome do cliente: " +this.getNome());
		System.out.println("Endereco do cliente: " +this.getEndereco());
		System.out.println("Telefone do clente: " +this.getTelefone()+"\n");
		
	}
}
